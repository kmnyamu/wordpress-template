<?php get_header();?>

<?php alvida_single_banner();?>

		<!-- START PORTFOLIO SINGLE PROJECT -->
		<section class="single_project">	
			<div class="container">
				<div class="row">
				<?php while(have_posts()) : the_post() ;
				
				$alvida_port_image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()),'alvida_image_770_510');
				$client_label_label = get_post_meta(get_the_ID(), '_alvida_port_client_label', true);
				$port_client_name = get_post_meta(get_the_ID(), '_alvida_port_client_name', true);
				$port_date_label = get_post_meta(get_the_ID(), '_alvida_port_date_label', true);
				$port_date = get_post_meta(get_the_ID(), '_alvida_port_date', true);
				$port_project_url_label = get_post_meta(get_the_ID(), '_alvida_port_project_url_label', true);
				$port_pro_url = get_post_meta(get_the_ID(), '_alvida_port_pro_url', true);
				?>
					<div class="col-md-8">
						<div class="project_dec">
						<img src="<?php echo esc_url($alvida_port_image['0']);?>" class="img-responsive" alt="" />		
						</div>
					</div>
					
					<div class="col-md-4">
						<div class="project_details">
							<div class="about_project">
								<h4><?php esc_html_e('About Project' , 'alvida');?></h4>
								<?php the_content();?>
							</div>
							<div class="about_project_details">
								<h4><?php esc_html_e('Project Details' , 'alvida');?></h4>
								<ul>
									<?php if($client_label_label) { ?>
										<li><i class="fa fa-user"></i><b><?php echo esc_html($client_label_label);?>: </b><?php echo esc_html($port_client_name);?></li>
									<?php }?>
									
									<?php if($port_date_label) { ?>
										<li><i class="fa fa-clock-o"></i><b><?php echo esc_html($port_date_label);?>: </b><?php echo esc_html($port_date);?></li>
									<?php }?>

									<?php if($port_project_url_label) { ?>
										<li><i class="fa fa-folder"></i><b><?php echo esc_html($port_project_url_label);?>: </b><a href="<?php echo esc_url($port_pro_url);?>" target="_blank"><?php echo esc_html($port_pro_url);?></a></li>
									<?php }?>
								</ul>
							</div>
							<?php if($port_pro_url) {?>
								<a class="btn-portfolio-bg" href="<?php echo esc_url($port_pro_url);?>" target="_blank"><?php echo esc_html_e('See Live Project' , 'alvida');?></a>
							<?php }?>
						</div>
					</div>
					
				<?php endwhile;?>	
			

					</div><!--- END ROW -->
						
						<div class="row">
							<div class="col-md-12"><h3 class="related_project"><?php echo esc_html_e('Related Projects' , 'alvida');?></h3></div>

								<?php // WP_Query arguments
								$args = array (
									'post_type'              => array( 'portfolios' ),
									'post__not_in' => array($post->ID),
									'posts_per_page'=> 3
								);

								// The Query
								$related_port_query = new WP_Query( $args );

								// The Loop
								if ( $related_port_query->have_posts() ) {
									while ( $related_port_query->have_posts() ) {
										$related_port_query->the_post(); 
										$alvida_port_image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()),'alvida_image_770_510');
										
										?>
				<div class="grid-item col-md-4 col-sm-4 col-xs-12 text-center">
					<div class="single_our_work">
						<div class="sing_work_photo">
							<figure>								
								<img src="<?php echo esc_url($alvida_port_image['0']);?>" alt="">
								<div class="sing_work_text_link">
									<div class="sing_work_content_wrap">
										<div class="sing_work_content">
										
										<?php $terms = get_the_terms(get_the_ID(), 'cat_portfolios');
												if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
													foreach ( $terms as $term ) {
											?>
											<h4><?php the_title();?></h4>
											<p><?php echo esc_html($term->name); ?></p>
										
											<?php
													}
											} ?>												
											
										
											<div class="sing_link_img">
												<a href="<?php echo esc_url($alvida_port_image['0']);?>" class="lightbox search" data-gall="gall-work"><i class="fa fa-eye"></i></a>
												<a href="<?php the_permalink();?>" class="link"><i class="fa fa-link"></i></a>
											</div>	
										</div>
									</div>
								</div>	
							</figure>
						</div>				
					</div>
				</div>
						
								<?php	}
								} else {
									// no posts found
								}

								// Restore original Post Data
								wp_reset_postdata();?>							
							
					</div>
								
			</div><!--- END CONTAINER -->
		</section>	
		<!-- END PORTFOLIO SINGLE PROJECT -->
		
<?php get_footer();?>
