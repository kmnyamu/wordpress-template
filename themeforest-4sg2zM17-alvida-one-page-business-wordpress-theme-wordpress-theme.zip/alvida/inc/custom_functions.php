<?php

function alvida_shop_banner(){ 
global $alvida;
$alvida_home_banner_img = $alvida['alvida_home_banner_img']['url'];	
$alvida_default_banner_img = get_template_directory_uri() . '/assets/img/bg/home-bg.jpg';

?>

	<!-- START  HOME DESIGN -->
	<section class="section-top" style="background: url(<?php if($alvida_home_banner_img){ echo esc_url($alvida_home_banner_img);}else{ echo esc_url($alvida_default_banner_img);}?>)no-repeat;background-size:cover; background-position: center center;background-attachment:fixed">
		<div class="overlay">
			<div class="container">
				<div class="col-md-10 col-md-offset-1 col-xs-12 text-center">
					<div class="section-top-title" data-wow-duration="1s" data-wow-delay="0.3s" data-wow-offset="0">
						<h2><?php esc_html_e('Shop' , 'alvida');?></h2>
						<ol class="breadcrumb">
						  <li><a href="<?php echo esc_url(home_url('/'));?>"><?php esc_html_e('Home' , 'alvida');?></a></li>
						  <li class="active"><?php esc_html_e('Shop' , 'alvida');?></li>
						</ol>
					</div><!-- //.HERO-TEXT -->
				</div><!--- END COL -->
			</div><!--- END CONTAINER -->
		</div><!--- END HOME OVERLAY -->
	</section>	
	<!-- END  HOME DESIGN -->	
		
<?php }

function alvida_blog_banner(){ 
global $alvida;
$alvida_home_banner_img = $alvida['alvida_home_banner_img']['url'];	
$alvida_default_banner_img = get_template_directory_uri() . '/assets/img/bg/home-bg.jpg';

?>

	<!-- START  HOME DESIGN -->
	<section class="section-top" style="background: url(<?php if($alvida_home_banner_img){ echo esc_url($alvida_home_banner_img);}else{ echo esc_url($alvida_default_banner_img);}?>)no-repeat;background-size:cover; background-position: center center;background-attachment:fixed">
		<div class="overlay">
			<div class="container">
				<div class="col-md-10 col-md-offset-1 col-xs-12 text-center">
					<div class="section-top-title" data-wow-duration="1s" data-wow-delay="0.3s" data-wow-offset="0">
						<h2><?php esc_html_e('Blog' , 'alvida');?></h2>
						<ol class="breadcrumb">
						  <li><a href="<?php echo esc_url(home_url('/'));?>"><?php esc_html_e('Home' , 'alvida');?></a></li>
						  <li class="active"><?php esc_html_e('Blog' , 'alvida');?></li>
						</ol>
					</div><!-- //.HERO-TEXT -->
				</div><!--- END COL -->
			</div><!--- END CONTAINER -->
		</div><!--- END HOME OVERLAY -->
	</section>	
	<!-- END  HOME DESIGN -->	
		
<?php }


function alvida_archive_banner(){ 
global $alvida;
$alvida_home_banner_img = $alvida['alvida_home_banner_img']['url'];	
$alvida_default_banner_img = get_template_directory_uri() . '/assets/img/bg/home-bg.jpg';

?>

	<!-- START  HOME DESIGN -->
	<section class="section-top" style="background: url(<?php if($alvida_home_banner_img){ echo esc_url($alvida_home_banner_img);}else{ echo esc_url($alvida_default_banner_img);}?>)no-repeat;background-size:cover; background-position: center center;background-attachment:fixed">
		<div class="overlay">
			<div class="container">
				<div class="col-md-10 col-md-offset-1 col-xs-12 text-center">
					<div class="section-top-title" data-wow-duration="1s" data-wow-delay="0.3s" data-wow-offset="0">
						<h2><?php esc_html_e('Archive' , 'alvida');?></h2>
						<ol class="breadcrumb">
						  <li><a href="<?php echo esc_url(home_url('/'));?>"><?php esc_html_e('Home' , 'alvida');?></a></li>
						  <li class="active"><?php the_archive_title();?></li>
						</ol>
					</div><!-- //.HERO-TEXT -->
				</div><!--- END COL -->
			</div><!--- END CONTAINER -->
		</div><!--- END HOME OVERLAY -->
	</section>	
	<!-- END  HOME DESIGN -->	
		
<?php }

function alvida_search_banner(){ 
global $alvida;
$alvida_home_banner_img = $alvida['alvida_home_banner_img']['url'];	
$alvida_default_banner_img = get_template_directory_uri() . '/assets/img/bg/home-bg.jpg';

?>

	<!-- START  HOME DESIGN -->
	<section class="section-top" style="background: url(<?php if($alvida_home_banner_img){ echo esc_url($alvida_home_banner_img);}else{ echo esc_url($alvida_default_banner_img);}?>)no-repeat;background-size:cover; background-position: center center;background-attachment:fixed">
		<div class="overlay">
			<div class="container">
				<div class="col-md-10 col-md-offset-1 col-xs-12 text-center">
					<div class="section-top-title" data-wow-duration="1s" data-wow-delay="0.3s" data-wow-offset="0">
						<h2><?php esc_html_e('Search' , 'alvida');?></h2>
						<ol class="breadcrumb">
						  <li><a href="<?php echo esc_url(home_url('/'));?>"><?php esc_html_e('Home' , 'alvida');?></a></li>
						  <li class="active"><?php printf( esc_html__( 'Search Results for: %s', 'alvida' ), '<span>' . get_search_query() . '</span>' ); ?></li>
						</ol>
					</div><!-- //.HERO-TEXT -->
				</div><!--- END COL -->
			</div><!--- END CONTAINER -->
		</div><!--- END HOME OVERLAY -->
	</section>	
	<!-- END  HOME DESIGN -->	
		
<?php }

function alvida_404_banner(){ 
global $alvida;
$alvida_home_banner_img = $alvida['alvida_home_banner_img']['url'];	
$alvida_default_banner_img = get_template_directory_uri() . '/assets/img/bg/home-bg.jpg';

?>

	<!-- START  HOME DESIGN -->
	<section class="section-top" style="background: url(<?php if($alvida_home_banner_img){ echo esc_url($alvida_home_banner_img);}else{ echo esc_url($alvida_default_banner_img);}?>)no-repeat;background-size:cover; background-position: center center;background-attachment:fixed">
		<div class="overlay">
			<div class="container">
				<div class="col-md-10 col-md-offset-1 col-xs-12 text-center">
					<div class="section-top-title" data-wow-duration="1s" data-wow-delay="0.3s" data-wow-offset="0">
						<h2><?php esc_html_e('404' , 'alvida');?></h2>
						<ol class="breadcrumb">
						  <li><a href="<?php echo esc_url(home_url('/'));?>"><?php esc_html_e('Home' , 'alvida');?></a></li>
						  <li class="active"><?php esc_html_e('404' , 'alvida');?></li>
						</ol>
					</div><!-- //.HERO-TEXT -->
				</div><!--- END COL -->
			</div><!--- END CONTAINER -->
		</div><!--- END HOME OVERLAY -->
	</section>	
	<!-- END  HOME DESIGN -->	
		
<?php }

function alvida_single_banner(){ 
global $alvida;

$alvida_home_banner_img = $alvida['alvida_home_banner_img']['url'];	
$alvida_upload_banner_image = get_post_meta(get_the_ID(), '_alvida_upload_banner_image', true);
$alvida_default_banner_img = get_template_directory_uri() . '/assets/img/bg/home-bg.jpg';

?>

	<!-- START  HOME DESIGN -->
	<section class="section-top" style="background: url(<?php if($alvida_upload_banner_image){ echo esc_url($alvida_upload_banner_image);}elseif($alvida_home_banner_img){ echo esc_url($alvida_home_banner_img);}else{ echo esc_url($alvida_default_banner_img);}?>)no-repeat;background-size:cover; background-position: center center;background-attachment:fixed">
		<div class="overlay">
			<div class="container">
				<div class="col-md-10 col-md-offset-1 col-xs-12 text-center">
					<div class="section-top-title" data-wow-duration="1s" data-wow-delay="0.3s" data-wow-offset="0">
						<h2><?php the_title();?></h2>
						<ol class="breadcrumb">
						  <li><a href="<?php echo esc_url(home_url('/'));?>"><?php esc_html_e('Home' , 'alvida');?></a></li>
						  <li class="active"><?php the_title();?></li>
						</ol>
					</div><!-- //.HERO-TEXT -->
				</div><!--- END COL -->
			</div><!--- END CONTAINER -->
		</div><!--- END HOME OVERLAY -->
	</section>	
	<!-- END  HOME DESIGN -->	
		
<?php }

function alvida_header(){ 

	global $alvida;
	$alvida_preloader_opt =  $alvida['alvida_preloader_opt'];
	$alvida_homepage_opt =  $alvida['alvida_homepage_opt'];
	$alvida_spinner_text =  $alvida['alvida_spinner_text'];
	$alvida_default_logo_img = get_template_directory_uri() . '/assets/img/logo.png';
	
?>

	<?php if($alvida_preloader_opt == '1' && !$alvida_homepage_opt == '1') { ?>
		
		<!-- START PRELOADER -->
		<div class="preloader">
			<div class="status">
				<div class="status-mes"><h4><?php echo esc_html($alvida_spinner_text);?></h4></div>
			</div>
		</div>
		<!-- END PRELOADER -->
	
	<?php }elseif($alvida_preloader_opt == '1' && $alvida_homepage_opt == '1'){ ?>	

	<?php if(is_front_page()) {?>
		<!-- START PRELOADER -->
		<div class="preloader">
			<div class="status">
				<div class="status-mes"><h4><?php echo esc_html($alvida_spinner_text);?></h4></div>
			</div>
		</div>
		<!-- END PRELOADER -->
	<?php } } ?>
	

		
<!-- START NAVBAR -->
<div class="navbar navbar-default navbar-fixed-top menu-top">
	<div class="container">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="sr-only"><?php esc_html_e('Toggle navigation' , 'alvida');?></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			
			<a href="<?php echo esc_url(home_url('/'));?>" class="navbar-brand">
				<?php if(get_custom_logo()){
					 the_custom_logo();
				}else { ?>
				  <img src="<?php echo esc_url($alvida_default_logo_img);?>" alt="">
				<?php } ?>		
			</a>
		</div>
		
		<div class="navbar-collapse collapse">
			<nav id="navigation">
				<?php alvida_main_menu();?>
			</nav>
		</div> 
	</div><!--- END CONTAINER -->
</div> 
<!-- END NAVBAR -->	

<?php
	
}

function alvida_footer(){ 
	global $alvida;
	$alvida_default_logo_img = get_template_directory_uri() . '/assets/img/logo.png';
	$alvida_copywrite_text =  $alvida['alvida_copywrite_text'];
	$alvida_footer_fb_link = $alvida['alvida_footer_fb_link'];	
	$alvida_footer_tw_link = $alvida['alvida_footer_tw_link'];	
	$alvida_footer_gplus_link = $alvida['alvida_footer_gplus_link'];	
	$alvida_footer_linkedin_link = $alvida['alvida_footer_linkedin_link'];	
	$alvida_footer_youtube_link = $alvida['alvida_footer_youtube_link'];	
	$alvida_footer_skype_link = $alvida['alvida_footer_skype_link'];	
?>
<!-- START FOOTER -->
<footer class="footer section-padding">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 text-center wow zoomIn">
				<div class="footer_content">
					<div class="footer_logo">
						<a href="<?php echo esc_url(home_url('/'));?>">
							<?php if(get_custom_logo()){
								 the_custom_logo();
							}else { ?>
							  <img src="<?php echo esc_url($alvida_default_logo_img);?>" alt="">
							<?php } ?>		
						</a>
					</div>	
					
					<div class="footer_social">
						<ul>
							<?php if($alvida_footer_fb_link){ ?>
								<li><a class="f_facebook wow bounceInDown" href="<?php echo esc_url($alvida_footer_fb_link);?>"><i class="fa fa-facebook"></i></a></li>
							<?php } if($alvida_footer_tw_link){ ?>
								<li><a class="f_twitter wow bounceInDown" data-wow-delay=".1s" href="<?php echo esc_url($alvida_footer_tw_link);?>"><i class="fa fa-twitter"></i></a></li>
							<?php } if($alvida_footer_gplus_link){ ?>
								<li><a class="f_google wow bounceInDown" data-wow-delay=".2s" href="<?php echo esc_url($alvida_footer_gplus_link);?>"><i class="fa fa-google-plus"></i></a></li>
							<?php } if($alvida_footer_linkedin_link){ ?>
								<li><a class="f_linkedin wow bounceInDown" data-wow-delay=".3s" href="<?php echo esc_url($alvida_footer_linkedin_link);?>"><i class="fa fa-linkedin"></i></a></li>
							<?php } if($alvida_footer_youtube_link){ ?>
								<li><a class="f_youtube wow bounceInDown" data-wow-delay=".4s" href="<?php echo esc_url($alvida_footer_youtube_link);?>"><i class="fa fa-youtube"></i></a></li>
							<?php } if($alvida_footer_skype_link){ ?>
								<li><a class="f_skype wow bounceInDown" data-wow-delay=".5s" href="<?php echo esc_url($alvida_footer_skype_link);?>"><i class="fa fa-skype"></i></a></li>
							<?php } ?>
						</ul>
					</div>	
					
					<div class="copyright">
						<p><?php echo alvida_wp_kses($alvida_copywrite_text);?></p>
					</div>
				</div>
										
			</div><!--- END COL -->
		</div><!--- END ROW -->
	</div><!--- END CONTAINER -->	
</footer>
<!-- END FOOTER -->			
<?php }