<?php


add_action( 'cmb2_init', 'alvida_metabox_options' );

function alvida_metabox_options(){
	// Start with an underscore to hide fields from custom fields list
	$prefix = '_alvida_';


	// Page Options	

	$cmb2_post_1_options = new_cmb2_box( array(
		'id'           => $prefix . 'p1banner_option',
		'title'        => esc_html__( 'Upload Banner Image', 'alvida' ),
		'object_types' => array( 'page' , 'post', 'portfolios'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );

	$cmb2_post_1_options->add_field( array(
	    'id'               => $prefix .'upload_banner_image',
	    'desc'             => esc_html__( 'Please upload banner image here ','alvida' ),
		 'type'             => 'file',
	) );	
	
	//Post Options	
	$cmb2_post_options = new_cmb2_box( array(
		'id'           => $prefix . 'posts_option',
		'title'        => esc_html__( 'Post Options', 'alvida' ),
		'object_types' => array( 'post'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );	
	
	
	$cmb2_post_options->add_field( array(
	    'name'             => esc_html__('Audio / Video Post Embed Code ' , 'alvida'),
	    'id'               => $prefix .'vid_post_title',
	    'type'    => 'title',
	) );		
	
	$cmb2_post_options->add_field( array(
	    'name'             => esc_html__('Embed Code' , 'alvida'),
	    'id'               => $prefix .'embed_code',
		'desc'    => esc_html__('enter embed code here' , 'alvida'),
	    'type'    => 'textarea_code',
	) );		
	$cmb2_about_us = new_cmb2_box( array(
		'id'           => $prefix . 'about_us_options',
		'title'        => esc_html__( 'About Us Info', 'alvida' ),
		'object_types' => array( 'about'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );

	$cmb2_about_us->add_field( array(
	    'name'             => esc_html__('Icon' , 'alvida'),
	    'id'               => $prefix .'cmb2_about_us_icon',
	    'desc'             => esc_html__( 'write icon here','alvida' ),
		'type'             => 'text',
		'default'             => 'fa fa-tablet',
	) );		
	
	$cmb2_about_us->add_field( array(
	    'name'             => esc_html__('Box Color' , 'alvida'),
	    'id'               => $prefix .'cmb2_about_us_box_color',
	    'desc'             => esc_html__( 'select here','alvida' ),
		'type'             => 'select',
		'default'             => 'about_single_one',
		'options'          => array(
			'about_single_one' => esc_html__( 'One', 'alvida' ),
			'about_single_two'   => esc_html__( 'Two', 'alvida' ),
			'about_single_three'     => esc_html__( 'Three', 'alvida' ),
			'about_single_four'     => esc_html__( 'Four', 'alvida' ),
		),
	) );	

	$cmb2_features = new_cmb2_box( array(
		'id'           => $prefix . 'features_options',
		'title'        => esc_html__( 'Features Info', 'alvida' ),
		'object_types' => array( 'features'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );

	$cmb2_features->add_field( array(
	    'name'             => esc_html__('Icon' , 'alvida'),
	    'id'               => $prefix .'features_icon',
	    'desc'             => esc_html__( 'write icon here','alvida' ),
		'type'             => 'text',
		'default'             => 'fa fa-lightbulb-o',
	) );	
	
	$cmb2_service = new_cmb2_box( array(
		'id'           => $prefix . 'service_options',
		'title'        => esc_html__( 'Service Info', 'alvida' ),
		'object_types' => array( 'service'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );

	$cmb2_service->add_field( array(
	    'name'             => esc_html__('Icon' , 'alvida'),
	    'id'               => $prefix .'service_icon',
	    'desc'             => esc_html__( 'write icon here','alvida' ),
		'type'             => 'text',
		'default'    => 'fa fa-paper-plane',
	) );	
	
	
	$cmb2_portfolios = new_cmb2_box( array(
		'id'           => $prefix . 'port_options',
		'title'        => esc_html__( 'Portfolios Info', 'alvida' ),
		'object_types' => array( 'portfolios'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );

	$cmb2_portfolios->add_field( array(
	    'name'             => esc_html__('Client Label' , 'alvida'),
	    'id'               => $prefix .'port_client_label',
	    'desc'             => esc_html__( 'write client Label here','alvida' ),
		'type'             => 'text',
		'default'    => 'Client',
	) );		
	
	$cmb2_portfolios->add_field( array(
	    'name'             => esc_html__('Client Name' , 'alvida'),
	    'id'               => $prefix .'port_client_name',
	    'desc'             => esc_html__( 'write client name here','alvida' ),
		'type'             => 'text',
		'default'    => 'Themeforest',
	) );	
	
	$cmb2_portfolios->add_field( array(
	    'name'             => esc_html__('Date Label' , 'alvida'),
	    'id'               => $prefix .'port_date_label',
	    'desc'             => esc_html__( 'write date Label here','alvida' ),
		'type'             => 'text',
		'default'    => 'Project Date',
	) );		
	
	$cmb2_portfolios->add_field( array(
	    'name'             => esc_html__('Date' , 'alvida'),
	    'id'               => $prefix .'port_date',
	    'desc'             => esc_html__( 'write Date here','alvida' ),
		'type'             => 'text',
		'default'    => 'February 18, 2016',
	) );		
	
	$cmb2_portfolios->add_field( array(
	    'name'             => esc_html__('Project Url Label' , 'alvida'),
	    'id'               => $prefix .'port_project_url_label',
	    'desc'             => esc_html__( 'write date Label here','alvida' ),
		'type'             => 'text',
		'default'    => 'Project Url',
	) );		
	
	$cmb2_portfolios->add_field( array(
	    'name'             => esc_html__('Project Url' , 'alvida'),
	    'id'               => $prefix .'port_pro_url',
	    'desc'             => esc_html__( 'write project url here','alvida' ),
		'type'             => 'text',
		'default'    => 'www.themeforest.net',
	) );	
		
	$cmb2_testi = new_cmb2_box( array(
		'id'           => $prefix . 'testimonials_options',
		'title'        => esc_html__( 'Testimonials Info', 'alvida' ),
		'object_types' => array( 'testimonials'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );
	
	$cmb2_testi->add_field( array(
		'name'             => esc_html__('Designation' , 'alvida'),
		'id'               => $prefix .'testimonials_designation',
		'desc'             => esc_html__( 'write text here','alvida' ),
		'type'             => 'text',
		'default'    => 'Company Name',
	) );

	
	$cmb2_pricing = new_cmb2_box( array(
		'id'           => $prefix . 'pric_options',
		'title'        => esc_html__( 'Pricing Info', 'alvida' ),
		'object_types' => array( 'pricing'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );
	
	$cmb2_pricing->add_field( array(
		'name'             => esc_html__('Pricing Currency' , 'alvida'),
		'id'               => $prefix .'pricing_currency',
		'desc'             => esc_html__( 'write text here','alvida' ),
		'type'             => 'text',
		'default'    => '$',
	) );		
	
	$cmb2_pricing->add_field( array(
		'name'             => esc_html__('Pricing Amount' , 'alvida'),
		'id'               => $prefix .'pricing_amount',
		'desc'             => esc_html__( 'write text here','alvida' ),
		'type'             => 'text',
		'default'    => '29',
	) );	
	
	$cmb2_pricing->add_field( array(
		'name'             => esc_html__('Pricing Period' , 'alvida'),
		'id'               => $prefix .'pricing_period',
		'desc'             => esc_html__( 'write text here','alvida' ),
		'type'             => 'text',
		'default'    => '/month',
	) );		
	$pricing_group_field_id = $cmb2_pricing->add_field( array(
		'id'          => $prefix .'pricing_group_field_opt',
		'type'        => 'group',
		// 'repeatable'  => false, // use false if you want non-repeatable group
		'options'     => array(
			'group_title'   => esc_html__( 'Feature {#}', 'alvida' ), // since version 1.1.4, {#} gets replaced by row number
			'add_button'    => esc_html__( 'Add New Feature', 'alvida' ),
			'remove_button' => esc_html__( 'Remove Feature', 'alvida' ),
			'sortable'      => true, // beta
			// 'closed'     => true, // true to have the groups closed by default
		),
	) );

	// Id's for group's fields only need to be unique for the group. Prefix is not needed.
	$cmb2_pricing->add_group_field( $pricing_group_field_id, array(
		'name' => esc_html__('Single Feature' , 'alvida'),
		'id'   => $prefix .'single_feature',
		'type' => 'textarea_small',
		'default' => 'Free Access',
		'description' => esc_html__('write text here' , 'alvida'),
		// 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
	) );
	$cmb2_pricing->add_field( array(
		'name'             => esc_html__('Button Text' , 'alvida'),
		'id'               => $prefix .'pricing_btn_text',
		'desc'             => esc_html__( 'write text here','alvida' ),
		'type'             => 'text',
		'default'    => 'Get Start',
	) );		
	$cmb2_pricing->add_field( array(
		'name'             => esc_html__('Button Link' , 'alvida'),
		'id'               => $prefix .'pricing_btn_link',
		'desc'             => esc_html__( 'write text here','alvida' ),
		'type'             => 'text',
		'default'    => '#',
	) );		
	$cmb2_team = new_cmb2_box( array(
		'id'           => $prefix . 'team_mem_options',
		'title'        => esc_html__( 'Team Member Info', 'alvida' ),
		'object_types' => array('team'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );

	
	$cmb2_team->add_field( array(
	    'name'             => esc_html__('Designation' , 'alvida'),
	    'id'               => $prefix .'team_designation',
	    'desc'             => esc_html__( 'write designation here','alvida' ),
		'type'       => 'text',
		'default'       => 'Designer',
	) );		
	
	$teamgroup_field_id = $cmb2_team->add_field( array(
		'id'          => $prefix .'team_group_field_opt',
		'type'        => 'group',
		// 'repeatable'  => false, // use false if you want non-repeatable group
		'options'     => array(
			'group_title'   => esc_html__( 'Social Media link {#}', 'alvida' ), // since version 1.1.4, {#} gets replaced by row number
			'add_button'    => esc_html__( 'Add New Link', 'alvida' ),
			'remove_button' => esc_html__( 'Remove Link', 'alvida' ),
			'sortable'      => true, // beta
			// 'closed'     => true, // true to have the groups closed by default
		),
	) );


	$cmb2_team->add_group_field( $teamgroup_field_id, array(
	    'name'             => esc_html__('Social Icon' , 'alvida'),
	    'id'               => $prefix .'social_icon',
	    'desc'             => esc_html__( 'write icon here. get all icon here http://fontawesome.io/icons/ ','alvida' ),
		'type'             => 'text',
		'default'    => 'fa-facebook',
	) );		
  
	$cmb2_team->add_group_field( $teamgroup_field_id, array(
	    'name'             => esc_html__('Social Link' , 'alvida'),
	    'id'               => $prefix .'social_link',
	    'desc'             => esc_html__( 'write url here','alvida' ),
		'type'             => 'text',
		'default'    => '#',
	) );		
  
  	$cmb2_team->add_group_field( $teamgroup_field_id, array(
	    'name'             => esc_html__('Backgorund Color' , 'alvida'),
	    'id'               => $prefix .'team_sbg_color',
	    'desc'             => esc_html__( 'choice color here','alvida' ),
		'type'             => 'colorpicker',

	) );	

	$cmb2_clients = new_cmb2_box( array(
		'id'           => $prefix . 'client_options',
		'title'        => esc_html__( 'Client Info', 'alvida' ),
		'object_types' => array( 'clients'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );

	$cmb2_clients->add_field( array(
		'name'             => esc_html__('Client Website Address' , 'alvida'),
		'id'               => $prefix .'client_web_url',
		'desc'             => esc_html__( 'enter url here','alvida' ),
		'type'             => 'text',
	) );	
	
}