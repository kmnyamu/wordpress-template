<?php 
function alvida_movers_custom_css(){
	global $alvida;
	
	if(!is_admin()) :
	?>
  
	<?php 
	
		$alvida_menu_text_color						 = '';
		$alvida_menu_text_hover_acive_color						 = '';
		$alvida_sticky_menu_bg_color						 = '';
		$alvida_sticky_menu_text_color						 = '';
		$alvida_sticky_menu_text_hover_acive_color						 = '';
		$alvida_footer_bg_color						 = '';
		$alvida_footer_bottom_bg_color						 = '';
		$alvida_footer_text_color						 = '';
		$alvida_spinner_bg_color						 = '';
		$alvida_spinner_image						 = '';
		$alvida_theme_color						 = '';
		$alvida_css_editor						 = '';
		

		if ( isset( $alvida['alvida_menu_text_color'] ) ) {
			$alvida_menu_text_color = $alvida['alvida_menu_text_color'];
		}		
		if ( isset( $alvida['alvida_menu_text_hover_acive_color'] ) ) {
			$alvida_menu_text_hover_acive_color = $alvida['alvida_menu_text_hover_acive_color'];
		}			
		if ( isset( $alvida['alvida_sticky_menu_bg_color'] ) ) {
			$alvida_sticky_menu_bg_color = $alvida['alvida_sticky_menu_bg_color'];
		}		
		if ( isset( $alvida['alvida_sticky_menu_text_color'] ) ) {
			$alvida_sticky_menu_text_color = $alvida['alvida_sticky_menu_text_color'];
		}			
		if ( isset( $alvida['alvida_sticky_menu_text_hover_acive_color'] ) ) {
			$alvida_sticky_menu_text_hover_acive_color = $alvida['alvida_sticky_menu_text_hover_acive_color'];
		}	
	
		if ( isset( $alvida['alvida_footer_bg_color'] ) ) {
			$alvida_footer_bg_color = $alvida['alvida_footer_bg_color'];
		}			
		
		if ( isset( $alvida['alvida_footer_text_color'] ) ) {
			$alvida_footer_text_color = $alvida['alvida_footer_text_color'];
		}			
		
		if ( isset( $alvida['alvida_spinner_image'] ) ) {
			$alvida_spinner_image = $alvida['alvida_spinner_image']['url'];
		}			
		
		if ( isset( $alvida['alvida_spinner_bg_color'] ) ) {
			$alvida_spinner_bg_color = $alvida['alvida_spinner_bg_color'];
		}			
		
		if ( isset( $alvida['alvida_theme_color'] ) ) {
			$alvida_theme_color = $alvida['alvida_theme_color'];
		}	
		if ( isset( $alvida['alvida_css_editor'] ) ) {
			$alvida_css_editor = $alvida['alvida_css_editor'];
		}
	

	wp_enqueue_style( 'alvida-custom-css', get_template_directory_uri() . '/assets/css/custom-style.css' );
	
	//add custom css
	$alvida_custom_css = "

		.preloader {
			background: {$alvida_spinner_bg_color};
		}			
		
		
		.status {
			background-image: url($alvida_spinner_image);
			background-position: center;
			background-repeat: no-repeat;
		}			
		
		.menu-top li a {
			color: {$alvida_menu_text_color}!important;
		}		
		
		.menu-top li a:hover {
			color: {$alvida_menu_text_hover_acive_color}!important;
		}		
		
		.navbar-default.menu-shrink {
			background: {$alvida_sticky_menu_bg_color};
		}		
		.navbar-default.menu-shrink li a {
			color: {$alvida_sticky_menu_text_color}!important;
		}	
		.navbar-default.menu-shrink li a:hover{
			color: {$alvida_sticky_menu_text_hover_acive_color} !important;
		}		
		
		.footer{
			background: {$alvida_footer_bg_color};
		}		
		.footer p{
			color: {$alvida_footer_text_color};
		}		

		a, a:hover,
		.widget-area a:hover,
		.single_feature:hover i,
		.service:hover .icon,
		.counter:hover i,
		.pricing-table-default:hover .btn,
		.pricing-table-default:hover .price,
		.blog-text span,
		.btn-blog-bg:hover,
		.entry-title a:hover,
		.woocommerce div.product .woocommerce-tabs ul.tabs li a
		{
			color: {$alvida_theme_color};
		}

		
		.btn-portfolio-bg,
		.nav-links .nav-previous a, 
		.nav-links .nav-next a,
		.form-control:focus,
		.btn-home-bg,
		.carousel-indicators li,
		.our_work_menu ul li:hover, 
		.our_work_menu ul li.active,
		.counter i,
		.counter:hover i,
		.team_text ul.social li a i:hover,
		.form-control:focus,
		.woocommerce #respond input#submit:hover, 
		.woocommerce a.button:hover, 
		.woocommerce button.button:hover, 
		.woocommerce input.button:hover,
		.woocommerce div.product form.cart .button,
		.woocommerce div.product .woocommerce-tabs ul.tabs::before,
		.woocommerce div.product .woocommerce-tabs ul.tabs li
		{
			border-color: {$alvida_theme_color};
		}
		
		.btn-portfolio-bg,
		#topcontrol,
		.nav-links .nav-previous a:hover, 
		.nav-links .nav-next a:hover,
		.form-submit #submit:hover, 
		.form-submit #submit:focus, 
		button:hover,
		.btn-home-bg,
		.section-title span,
		.single_feature i,
		.single_feature:hover,
		.service:hover,
		.carousel-indicators li,
		.our_work_menu ul li:hover, 
		.our_work_menu ul li.active,
		.sing_link_img a:hover,
		.btn-portfolio-bg,
		.counter i,
		.team_text ul.social li a i:hover,
		.progress-bar > span,
		.pricing-head .price,
		.contact-address,
		.widget .tagcloud a:hover,
		.navigation.pagination a:hover, 
		.woocommerce nav.woocommerce-pagination ul li a:focus, 
		.woocommerce nav.woocommerce-pagination ul li a:hover, 
		.navigation.pagination span, 
		.woocommerce nav.woocommerce-pagination ul li span.current,
		.woocommerce span.onsale,
		.woocommerce #respond input#submit:hover, 
		.woocommerce a.button:hover, 
		.woocommerce button.button:hover, 
		.woocommerce input.button:hover,
		.woocommerce div.product form.cart .button,
		.add_to_cat_btn button, 
		.woocommerce a.added_to_cart,
		.woocommerce .widget_price_filter .ui-slider .ui-slider-handle,
		.woocommerce .widget_price_filter .ui-slider .ui-slider-range{
			background: {$alvida_theme_color};
		}			

		.add_to_cat_btn button, 
		.woocommerce a.added_to_cart, 
		.continue-shopping.button, 
		.button.empty-cart, 
		.button.update, 
		.button.apply-coupon, 
		.checkout-button.button.alt.wc-forward, 
		#place_order, 
		.form-row.form-row-last .button, 
		.woocommerce .widget_price_filter .price_slider_amount .button, 
		.shipping-calculator-form .button, 
		form.login .button, 
		form.lost_reset_password .button, 
		#review_form_wrapper #submit{
			background: {$alvida_theme_color}!important;
			border-color: {$alvida_theme_color}!important;
		}			
		
		{$alvida_css_editor};
	";
	
	//Add the above custom CSS via wp_add_inline_style
	wp_add_inline_style( 'alvida-custom-css', $alvida_custom_css ); //Pass the variable into the main style sheet ID
	
	
  endif;
}

add_action( 'wp_enqueue_scripts', 'alvida_movers_custom_css'  ) ;