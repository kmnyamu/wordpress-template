<?php
 
add_action('init', 'alvida_kc_active', 99 );
 
function alvida_kc_active() {
 
	if (function_exists('kc_add_map')) 
		
	{ 
	
	    kc_add_map(
	        array(

	            'shortcode_importer' => array(
	                'name' => esc_html__('Shortcode Importer', 'alvida'),
	                'icon' => 'sl-rocket',
	                'category' => 'Alvida Shortcodes',
	                'params' => array(
	                
	                    array(
                        'name' => 'enter_shortcode',
                        'label' => esc_html__( 'Enter Shortcode', 'alvida' ),
                        'type' => 'textarea',
                        'admin_label' => true,
						),	    	                             


	                )
	            ),  // End of elemnt kc_icon 

	        ) 
			
			
	    ); // End add map	  
		
	    kc_add_map(
	        array(

	            'title_area' => array(
	                'name' => esc_html__('Title Area', 'alvida'),
	                'icon' => 'sl-rocket',
	                'category' => 'Alvida Shortcodes',
	                'params' => array(
	                
	                    array(
	                        'name' => 'sec_title',
	                        'label' => esc_html__( 'Title', 'alvida' ),
	                        'type' => 'text',
	                        'admin_label' => true,
							'value' => 'Our Skills',
						),	                   

						array(
	                        'name' => 'sec_subtitle',
	                        'label' => esc_html__( 'SubTitle', 'alvida' ),
	                        'type' => 'textarea',
	                        'admin_label' => true,
							'value' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation Lorem ipsum dolor sit amet.Veniam quis notru exercit.',
						),						
						
						array(
	                        'name' => 'select_color',
	                        'label' => esc_html__( 'Select Color', 'alvida' ),
	                        'type' => 'select',
	                        'admin_label' => true,
                           'options' => array(  
                              'black_color' => 'Black Color',
                              'white_color' => 'White Color',
                          )
						),						
												

	                )
	            ),  // End of elemnt kc_icon 

	        ) 
			
			
	    ); // End add map	    
		
		kc_add_map(
	        array(

	            'about_area' => array(
	                'name' => esc_html__('About Us Area', 'alvida'),
	                'icon' => 'sl-rocket',
	                'category' => 'Alvida Shortcodes',
	                'params' => array(

	                    array(
	                        'name' => 'sec_title',
	                        'label' => esc_html__( 'Section Title', 'alvida' ),
	                        'type' => 'text',
	                        'admin_label' => true,
							'value' => 'About us',
						),		                    
						
						array(
	                        'name' => 'sec_subtitle',
	                        'label' => esc_html__( 'Section SubTitle', 'alvida' ),
	                        'type' => 'textarea',
	                        'admin_label' => true,
							'value' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation Lorem ipsum dolor sit amet.Veniam quis notru exercit.',
						),	 						
						
						array(
	                        'name' => 'number_of_post',
	                        'label' => esc_html__( 'Number of Post', 'alvida' ),
	                        'type' => 'text',
	                        'admin_label' => true,
							'value' => '4',
						),							
											   
	                )
	            ),  // End of elemnt kc_icon 

	        ) 
			
			
	    ); // End add map			
		
		kc_add_map(
	        array(

	            'features_area' => array(
	                'name' => esc_html__('Features Area', 'alvida'),
	                'icon' => 'sl-rocket',
	                'category' => 'Alvida Shortcodes',
	                'params' => array(

	                    array(
	                        'name' => 'sec_title',
	                        'label' => esc_html__( 'Title', 'alvida' ),
	                        'type' => 'text',
	                        'admin_label' => true,
							'value' => 'Awesome Features',
						),		                    
						
						array(
	                        'name' => 'sec_subtitle',
	                        'label' => esc_html__( 'SubTitle', 'alvida' ),
	                        'type' => 'textarea',
	                        'admin_label' => true,
							'value' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation Lorem ipsum dolor sit amet.Veniam quis notru exercit.',
						),	 						
						
						array(
	                        'name' => 'number_of_post',
	                        'label' => esc_html__( 'Number of Post', 'alvida' ),
	                        'type' => 'text',
	                        'admin_label' => true,
							'value' => '4',
						),	 						
												   
	                )
	            ),  // End of elemnt kc_icon 

	        ) 
			
			
	    ); // End add map			
		
		kc_add_map(
	        array(

	            'service_area' => array(
	                'name' => esc_html__('Services Area', 'alvida'),
	                'icon' => 'sl-rocket',
	                'category' => 'Alvida Shortcodes',
	                'params' => array(
		                    
						
						array(
	                        'name' => 'section_image',
	                        'label' => esc_html__( 'Upload background Image', 'alvida' ),
	                        'type' => 'attach_image',
	                        'admin_label' => true,
						),	

	                    array(
	                        'name' => 'section_title',
	                        'label' => esc_html__( 'Title', 'alvida' ),
	                        'type' => 'text',
	                        'admin_label' => true,
							'value' => 'Our best service',
						), 		                   

						array(
	                        'name' => 'section_subtitle',
	                        'label' => esc_html__( 'subTitle', 'alvida' ),
	                        'type' => 'textarea',
	                        'admin_label' => true,
							'value' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation Lorem ipsum dolor sit amet.Veniam quis notru exercit.',
						), 						
												   
	                )
	            ),  // End of elemnt kc_icon 

	        ) 
			
			
	    ); // End add map			
		
		kc_add_map(
	        array(

	            'work_area' => array(
	                'name' => esc_html__('Work Area', 'alvida'),
	                'icon' => 'sl-rocket',
	                'category' => 'Alvida Shortcodes',
	                'params' => array(

	                    array(
	                        'name' => 'sec_title',
	                        'label' => esc_html__( 'Title', 'alvida' ),
	                        'type' => 'text',
	                        'admin_label' => true,
							'value' => 'Our Great Works',
						),			                   

						array(
	                        'name' => 'sec_subtitle',
	                        'label' => esc_html__( 'SubTitle', 'alvida' ),
	                        'type' => 'textarea',
	                        'admin_label' => true,
							'value' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation Lorem ipsum dolor sit amet.Veniam quis notru exercit.',
						),							
						array(
	                        'name' => 'sec_btn_text',
	                        'label' => esc_html__( 'Button Text', 'alvida' ),
	                        'type' => 'text',
	                        'admin_label' => true,
							'value' => 'See More',
						),								
						
						array(
	                        'name' => 'sec_btn_link',
	                        'label' => esc_html__( 'Button Link', 'alvida' ),
	                        'type' => 'text',
	                        'admin_label' => true,
							'value' => '#',
						),		                    
												
												   
	                )
	            ),  // End of elemnt kc_icon 

	        ) 			
	    ); // End add map			
		
		kc_add_map(
	        array(

	            'testimonials_area' => array(
	                'name' => esc_html__('Testimonials Area', 'alvida'),
	                'icon' => 'sl-rocket',
	                'category' => 'Alvida Shortcodes',
	                'params' => array(

	                    array(
	                        'name' => 'sec_title',
	                        'label' => esc_html__( 'Title', 'alvida' ),
	                        'type' => 'text',
	                        'admin_label' => true,
							'value' => 'What our clients say',
						),			                   

						array(
	                        'name' => 'sec_subtitle',
	                        'label' => esc_html__( 'SubTitle', 'alvida' ),
	                        'type' => 'textarea',
	                        'admin_label' => true,
							'value' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation Lorem ipsum dolor sit amet.Veniam quis notru exercit.',
						),							
								
												   
	                )
	            ),  // End of elemnt kc_icon 

	        ) 			
	    ); // End add map			
		
		kc_add_map(
	        array(

	            'counter_area' => array(
	                'name' => esc_html__('Counter Area', 'alvida'),
	                'icon' => 'sl-rocket',
	                'category' => 'Alvida Shortcodes',
					'nested'		=> true,
	                'params' => array(

								   
	                )
	            ),  // End of elemnt kc_icon 

	        ) 			
	    ); // End add map		
		
		kc_add_map(
	        array(

	            'counter_item' => array(
	                'name' => esc_html__('Counter Item (Child Of Counter)', 'alvida'),
	                'icon' => 'sl-rocket',
	                'category' => 'Alvida Shortcodes',			
	                'params' => array(
						array(
	                        'name' => 'sec_icon',
	                        'label' => esc_html__( 'Icon', 'alvida' ),
	                        'type' => 'text',
	                        'admin_label' => true,
							'value' => 'fa fa-check',
						),								
						
						array(
	                        'name' => 'sec_text',
	                        'label' => esc_html__( 'Counter Text', 'alvida' ),
	                        'type' => 'text',
	                        'admin_label' => true,
							'value' => 'Satisfied Clients',
						),								
						
						array(
	                        'name' => 'sec_number',
	                        'label' => esc_html__( 'Counter Number', 'alvida' ),
	                        'type' => 'text',
	                        'admin_label' => true,
							'value' => '2000',
						),			   
	                )
	            ),  // End of elemnt kc_icon 

	        ) 			
	    ); // End add map			
		
		kc_add_map(
	        array(

	            'team_area' => array(
	                'name' => esc_html__('Team Area', 'alvida'),
	                'icon' => 'sl-rocket',
	                'category' => 'Alvida Shortcodes',			
	                'params' => array(
							
						
						array(
	                        'name' => 'sec_title',
	                        'label' => esc_html__( 'Title', 'alvida' ),
	                        'type' => 'text',
	                        'admin_label' => true,
							'value' => 'Our Lovely team',
						),								
						
						array(
	                        'name' => 'sec_subtitle',
	                        'label' => esc_html__( 'SubTitle', 'alvida' ),
	                        'type' => 'textarea',
	                        'admin_label' => true,
							'value' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation Lorem ipsum dolor sit amet.Veniam quis notru exercit.',
						),							
						
						array(
	                        'name' => 'number_of_post',
	                        'label' => esc_html__( 'Number of Post', 'alvida' ),
	                        'type' => 'text',
	                        'admin_label' => true,
							'value' => '4',
						),								
						
		   
	                )
	            ),  // End of elemnt kc_icon 

	        ) 			
	    ); // End add map			
		
		kc_add_map(
	        array(

	            'progress_bar_area' => array(
	                'name' => esc_html__('Progress Bar Area', 'alvida'),
	                'icon' => 'sl-rocket',
	                'category' => 'Alvida Shortcodes',			
	                'params' => array(							
						
						array(
	                        'name' => 'sec_text',
	                        'label' => esc_html__( 'Section Text', 'alvida' ),
	                        'type' => 'text',
	                        'admin_label' => true,
							'value' => 'Branding',
						),					

						array(
	                        'name' => 'sec_number',
	                        'label' => esc_html__( 'Section Number', 'alvida' ),
	                        'type' => 'text',
	                        'admin_label' => true,
							'value' => '90',
						),							
													
		   
	                )
	            ),  // End of elemnt kc_icon 

	        ) 			
	    ); // End add map			
					
		
		kc_add_map(
	        array(

	            'pricing_area' => array(
	                'name' => esc_html__('Pricing Area', 'alvida'),
	                'icon' => 'sl-rocket',
	                'category' => 'Alvida Shortcodes',			
	                'params' => array(							
									

						array(
	                        'name' => 'sec_title',
	                        'label' => esc_html__( 'Section Title', 'alvida' ),
	                        'type' => 'text',
	                        'admin_label' => true,
							'value' => 'Our Pricing',
						),							
						
						array(
	                        'name' => 'sec_subtitle',
	                        'label' => esc_html__( 'Section SubTitle', 'alvida' ),
	                        'type' => 'textarea',
	                        'admin_label' => true,
							'value' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation Lorem ipsum dolor sit amet.Veniam quis notru exercit.',
						),							
						
						array(
	                        'name' => 'sec_number_post',
	                        'label' => esc_html__( 'Number of Post', 'alvida' ),
	                        'type' => 'text',
	                        'admin_label' => true,
							'value' => '4',							
						),								
		   
	                )
	            ),  // End of elemnt kc_icon 

	        ) 			
	    ); // End add map			
					
		
		kc_add_map(
	        array(

	            'blog_area' => array(
	                'name' => esc_html__('Blog Area', 'alvida'),
	                'icon' => 'sl-rocket',
	                'category' => 'Alvida Shortcodes',			
	                'params' => array(							
									
						array(
	                        'name' => 'sec_title',
	                        'label' => esc_html__( 'Section Title', 'alvida' ),
	                        'type' => 'text',	                        
	                        'admin_label' => true,
							'value' => 'Fresh news',
						),							
						
						array(
	                        'name' => 'sec_subtitle',
	                        'label' => esc_html__( 'Section SubTitle', 'alvida' ),
	                        'type' => 'textarea',	                        
	                        'admin_label' => true,
							'value' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation Lorem ipsum dolor sit amet.Veniam quis notru exercit.',
						),							

						array(
	                        'name' => 'sec_number_post',
	                        'label' => esc_html__( 'Number of Post', 'alvida' ),
	                        'type' => 'text',	                        
	                        'admin_label' => true,
							'value' => '3',
						),							
		   
	                )
	            ),  // End of elemnt kc_icon 

	        ) 			
	    ); // End add map			
		
		kc_add_map(
	        array(

	            'client_area' => array(
	                'name' => esc_html__('Clients Area', 'alvida'),
	                'icon' => 'sl-rocket',
	                'category' => 'Alvida Shortcodes',			
	                'params' => array(							
																			
		   
	                )
	            ),  // End of elemnt kc_icon 

	        ) 			
	    ); // End add map		

		kc_add_map(
	        array(

	            'contact_us_area' => array(
	                'name' => esc_html__('Contact Us Area', 'alvida'),
	                'icon' => 'sl-rocket',
	                'category' => 'Alvida Shortcodes',				
	                'params' => array(							
									
						array(
	                        'name' => 'sec_bg_img',
	                        'label' => esc_html__( 'Upload Background Image', 'alvida' ),
	                        'type' => 'attach_image',	                        
	                        'admin_label' => true,
						),						

						array(
	                        'name' => 'sec_title',
	                        'label' => esc_html__( 'Section Title', 'alvida' ),
	                        'type' => 'text',	                        
	                        'admin_label' => true,
							'value' => 'Get in touch',
						),							
						
						array(
	                        'name' => 'sec_subtitle',
	                        'label' => esc_html__( 'Section SubTitle', 'alvida' ),
	                        'type' => 'textarea',	                        
	                        'admin_label' => true,
							'value' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation Lorem ipsum dolor sit amet.Veniam quis notru exercit.',
						),							

						array(
	                        'name' => 'contact_form_shortcode',
	                        'label' => esc_html__( 'Enter Shortcode ID', 'alvida' ),
	                        'type' => 'textarea',	                        
	                        'admin_label' => true,
						),							
		   
	                )
	            ),  // End of elemnt kc_icon 

	        ) 			
	    ); // End add map			
		
		kc_add_map(
	        array(

	            'contact_info' => array(
	                'name' => esc_html__('Contact Info ', 'alvida'),
	                'icon' => 'sl-rocket',
	                'category' => 'Alvida Shortcodes',						
	                'params' => array(							
									
						array(
	                        'name' => 'cont_icon',
	                        'label' => esc_html__( 'Contact Icon', 'alvida' ),
	                        'type' => 'text',	                        
	                        'admin_label' => true,
							'value' => 'fa fa-phone',
						),							
						
						array(
	                        'name' => 'cont_content',
	                        'label' => esc_html__( 'Info', 'alvida' ),
	                        'type' => 'textarea',	                        
	                        'admin_label' => true,
							'value' => '<p>(+1) 740-395-3829</p> <p>(+1) 740-395-3829</p>',
						),							
					
		   
	                )
	            ),  // End of elemnt kc_icon 

	        ) 			
	    ); // End add map			
		
		kc_add_map(
	        array(

	            'google_map' => array(
	                'name' => esc_html__('Google Map Area', 'alvida'),
	                'icon' => 'sl-rocket',
	                'category' => 'Alvida Shortcodes',						
	                'params' => array(							
									
						array(
	                        'name' => 'map_api',
	                        'label' => esc_html__( 'API', 'alvida' ),
	                        'type' => 'text',	                        
	                        'admin_label' => true,
							'value' => 'AIzaSyDwIQh7LGryQdDDi-A603lR8NqiF3R_ycA',
						),							
						
						array(
	                        'name' => 'map_latitude',
	                        'label' => esc_html__( 'Latitude', 'alvida' ),
	                        'type' => 'text',	                        
	                        'admin_label' => true,
							'value' => '40.7127837',
						),						
						
						array(
	                        'name' => 'map_longitude',
	                        'label' => esc_html__( 'Longitude', 'alvida' ),
	                        'type' => 'text',	                        
	                        'admin_label' => true,
							'value' => '-74.00594130000002',
						),							
					
		   
	                )
	            ),  // End of elemnt kc_icon 

	        ) 			
	    ); // End add map			
				

	
	} // End if

}  
 
